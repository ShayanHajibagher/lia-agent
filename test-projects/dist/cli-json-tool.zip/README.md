# jsontool

ابزار خط فرمان برای زیبا کردن JSON.
