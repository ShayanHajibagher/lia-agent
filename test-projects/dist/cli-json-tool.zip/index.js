#!/usr/bin/env node
const fs = require('fs');
const file = process.argv[2];
if (!file) { console.log('usage: jsontool <file.json>'); process.exit(1); }
console.log(JSON.stringify(JSON.parse(fs.readFileSync(file, 'utf8')), null, 2));
