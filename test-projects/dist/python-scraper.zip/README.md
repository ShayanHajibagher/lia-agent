# اسکرپر

اجرا: `python scraper.py`
