import requests
from bs4 import BeautifulSoup

def main():
    html = requests.get('https://example.com', timeout=10).text
    soup = BeautifulSoup(html, 'html.parser')
    print(soup.title.string)

if __name__ == '__main__':
    main()
