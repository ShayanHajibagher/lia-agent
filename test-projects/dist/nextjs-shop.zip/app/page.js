import { getProducts } from '../lib/db';

export default async function Home() {
  const products = getProducts();
  return (<main><h1>فروشگاه نمونه</h1><ul>{products.map((p) => <li key={p.id}>{p.name}</li>)}</ul></main>);
}
