export const metadata = { title: 'فروشگاه نمونه' };
export default function RootLayout({ children }) {
  return (<html lang="fa" dir="rtl"><body>{children}</body></html>);
}
